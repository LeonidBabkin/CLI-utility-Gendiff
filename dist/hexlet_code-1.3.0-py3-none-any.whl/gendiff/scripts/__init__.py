# -*- coding: utf-8 -*-

"""Gendiff scripts."""
