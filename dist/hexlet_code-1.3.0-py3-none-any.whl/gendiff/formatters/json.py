import json

def build_json(datum):
    return json.dumps(datum).strip()
