### Hexlet tests and linter status:
[![Actions Status](https://github.com/LeonidBabkin/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/LeonidBabkin/python-project-50/actions)

<a href="https://codeclimate.com/github/LeonidBabkin/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/975e8468cd7f19ac6fd2/maintainability" /></a>
<a href="https://codeclimate.com/github/LeonidBabkin/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/975e8468cd7f19ac6fd2/test_coverage" /></a>

Project 2, step 3:
https://asciinema.org/a/LqBiSl2xtXNN7VigJfUapJQKH

