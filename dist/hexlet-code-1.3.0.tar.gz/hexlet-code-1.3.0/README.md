### Hexlet tests and linter status:
[![Actions Status](https://github.com/LeonidBabkin/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/LeonidBabkin/python-project-50/actions)

<a href="https://codeclimate.com/github/LeonidBabkin/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/975e8468cd7f19ac6fd2/maintainability" /></a>
<a href="https://codeclimate.com/github/LeonidBabkin/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/975e8468cd7f19ac6fd2/test_coverage" /></a>

Gendiff is a CLI utility for finding differences between configuration files.

Suppported formats: YAML, JSON
Report difference as a plain text, structured text or JSON

Can be used as an external library.

You can instal the project via pip install -i https://test.pypi.org/simple/ leonid-hexlet-code

Project 2, step 3:
https://asciinema.org/a/LqBiSl2xtXNN7VigJfUapJQKH

Project 2, step 5
https://asciinema.org/a/nXneXX0v3UDXJjEGrJl5h9M5y

Project 2, representation of a stylish format:
https://asciinema.org/a/h4Swze6RlXozjafnG97Nc5Wim

Project 2, representation of a plain format:
https://asciinema.org/a/3yo3H0Z6J3CQih47R6QXPNePY

Project 2, representation of a json format of the AST:
https://asciinema.org/a/1MWmtd01nVVuDY8y1H0yo0WM7
