### Hexlet tests and linter status:
[![Actions Status](https://github.com/LeonidBabkin/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/LeonidBabkin/python-project-50/actions)
Project 2, step 3:
https://asciinema.org/a/LqBiSl2xtXNN7VigJfUapJQKH
