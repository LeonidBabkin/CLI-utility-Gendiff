def make_plainish(dct):
    finale = []
    for key, value in dct.items():
        if len(value) == 2:
            print(value)
            if value[1] == 'added':
                finale.extend(f'Property \'{key}\' was added with value: {turn_value(value[0])}')
            elif value[1] == 'removed':
                finale.extend(f'Property \'{key}\' was removed')
        elif len(value) > 2:
            if value[3] == 'added':
                finale.extend(f'Property \'{key}\' was updated. From {turn_value(value[0])} to {turn_value(value[2])}')
    return '\n'.join(finale)
