# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.fixtures', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['coverage>=6.5.0,<7.0.0', 'pytest-cov>=4.0.0,<5.0.0', 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '1.3.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/LeonidBabkin/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/LeonidBabkin/python-project-50/actions)\n\n<a href="https://codeclimate.com/github/LeonidBabkin/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/975e8468cd7f19ac6fd2/maintainability" /></a>\n<a href="https://codeclimate.com/github/LeonidBabkin/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/975e8468cd7f19ac6fd2/test_coverage" /></a>\n\nProject 2, step 3:\nhttps://asciinema.org/a/LqBiSl2xtXNN7VigJfUapJQKH\n\nProject 2, step 5\nhttps://asciinema.org/a/nXneXX0v3UDXJjEGrJl5h9M5y\n\nProject 2, representation of a stylish format:\nhttps://asciinema.org/a/h4Swze6RlXozjafnG97Nc5Wim\n\nProject 2, representation of a plain format:\nhttps://asciinema.org/a/3yo3H0Z6J3CQih47R6QXPNePY\n\nProject 2, representation of a json format of the AST:\nhttps://asciinema.org/a/1MWmtd01nVVuDY8y1H0yo0WM7\n',
    'author': 'LeonidBabkin',
    'author_email': 'Babkinleo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
